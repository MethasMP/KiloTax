# KILOTAX RECORDED DATA WORKPAPER
Review records and tax treatment with your tax agent.
Taxpayer / Client: Not provided
ABN: Not provided
Vehicle: Toyota Corolla \(ABC123\)
Financial Year: 2026-27

## Recorded travel summary
- Total Logged: 20.0 km
- Business Kilometres: 0.0 km
- Business Use Percentage: 0.00%
This percentage describes the supplied records. It does not establish eligibility or a completed logbook.

## Receipt record checks
- Recorded expenses: 3
- Attached receipt references: 2 of 3
- Expenses with a saved receipt reference: $100.00
- Accessible on disk: 1 of 3
- Human-confirmed with available files: 0 of 3
- OCR-matched with available files: 0 of 3
- Missing or unconfirmed receipts: 3 of 3
File inspection is unknown when no inspection result was supplied. A saved OCR match is not human confirmation.
Vault-only expenses are records, not additions to the calculation. Use summary.pdf and review-issues.csv for the selected method and unresolved checks.

## Linked records
Links help locate related records. They do not establish business purpose or tax eligibility.
| Date | Expense ID | Category | Amount (AUD) | Linked trip ID | Recorded route | Archive file |
| --- | --- | --- | --- | --- | --- | --- |
| 2026-08-01 | missing | Fuel &amp; Oil | 50.00 | private | \[Private or unclassified journey\] | Not included |
| 2026-08-01 | present | Fuel &amp; Oil | 50.00 | private | \[Private or unclassified journey\] | receipts/receipt-000001.png |
| 2026-08-01 | vault | Fuel &amp; Oil | 50.00 | private | \[Private or unclassified journey\] | Not included |
