KiloTax recorded vehicle evidence package
Vehicle: ABC123
Financial year: 2026-27
Method: logbook
Status: Draft, review required
Receipt files: 1 of 3 expense records.
Review items: 3

A readable file means the application read nonempty bytes. It does not establish image legibility, authenticity, expense accuracy, or tax eligibility. Saved review status is historical metadata. A matching hash only establishes equality with the saved fingerprint.
Missing receipt files are not embedded. Remote receipt references are not downloaded during export. Restore receipts to this device and export again if needed.
The PDF calculation uses recorded data and is subject to review. Vault-only expenses are excluded from the calculation. For cents-per-kilometre, attached expenses are records and do not increase the distance-based calculation. Uncapped_Trip_Value_AUD in trips.csv is the uncapped value of each trip. The PDF total applies the kilometre cap.
Trip_Ledger_Data_Row in record-sources.csv is the one-based data row in trips.csv, excluding its header. A blank value means the record is not included in that method-specific ledger. Private and unclassified route addresses and purposes are masked in the trip ledger. Receipt images retain their original content, which may include personal information. Review before sharing.
This package is an accountant handoff, not a restorable application backup. No email delivery is established by preparing or sharing it.
